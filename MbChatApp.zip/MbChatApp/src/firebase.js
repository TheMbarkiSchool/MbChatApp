import firebase from "firebase/app";
import "firebase/auth";

export const auth = firebase.initializeApp({
    apiKey: "AIzaSyClcjUku-37kaFwDCtr3ov5zaKY6EOPrhU",
    authDomain: "mbchatapp-d63ff.firebaseapp.com",
    projectId: "mbchatapp-d63ff",
    storageBucket: "mbchatapp-d63ff.appspot.com",
    messagingSenderId: "333406311982",
    appId: "1:333406311982:web:8f8dc5b2f8666d70e331bf"
  }).auth();